List of things to do
====================

1. Keep image temporarly
2. Way to upload photos
3. Display photos on page
4. Organize photo by season/date/event
5. Show image catagories
6. Change images based off of selected catagories
7. Cookies = If new user erase all photos

Current issues
==============

+ formidable not working
++ https://www.npmjs.com/package/formidable-upload